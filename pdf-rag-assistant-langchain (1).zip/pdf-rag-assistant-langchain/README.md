# PDF RAG Assistant using LangChain

## Overview
This project implements a Retrieval-Augmented Generation (RAG) pipeline
that allows users to upload PDF documents and ask questions about them.

## Architecture
PDF → Chunking → Embeddings → FAISS → Retriever → LLM → Answer

## Tech Stack
- LangChain
- FAISS
- SentenceTransformers
- OpenAI
- Gradio

## How to Run

1. Install dependencies:
pip install -r requirements.txt

2. Set your OpenAI API key:
set OPENAI_API_KEY=your_key_here   (Windows)
export OPENAI_API_KEY=your_key_here  (Mac/Linux)

3. Run the app:
python app.py

Then open the browser link shown in terminal.
