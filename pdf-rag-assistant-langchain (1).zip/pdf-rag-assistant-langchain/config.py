CHUNK_SIZE = 500
CHUNK_OVERLAP = 100
VECTORSTORE_PATH = "vectorstore"
MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
