import gradio as gr
from ingestion import ingest_pdf
from rag_pipeline import load_qa_chain

qa_chain = None

def upload_and_process(file):
    global qa_chain
    
    if file is None:
        return "Please upload a PDF first."
    
    ingest_pdf(file.name)
    qa_chain = load_qa_chain()
    
    return "Document processed successfully! You can now ask questions."

def ask_question(question):
    global qa_chain
    
    if qa_chain is None:
        return "Please upload and process a document first."
    
    answer = qa_chain.run(question)
    return answer

with gr.Blocks() as demo:
    gr.Markdown("# PDF RAG Assistant")
    
    with gr.Tab("Upload Document"):
        file_input = gr.File(file_types=[".pdf"])
        upload_button = gr.Button("Process Document")
        upload_output = gr.Textbox()
        
        upload_button.click(upload_and_process, inputs=file_input, outputs=upload_output)
    
    with gr.Tab("Ask Questions"):
        question_input = gr.Textbox(label="Enter your question")
        ask_button = gr.Button("Ask")
        answer_output = gr.Textbox(label="Answer")
        
        ask_button.click(ask_question, inputs=question_input, outputs=answer_output)

demo.launch()
